/*
 Hello! Thank you for taking the time to complete our
 coding challenge. There are 3 challenges, each on a
 separate page. The clue derived from each page will
 provide instructions for the next challenge.

 We recommend turning "Editor > Show Rendered Markup"
 on for a classier experience.

 When you are done, please rename this playground to
 "first-last Ramp Challenge.playground" and submit it to
 ios-submissions@ramp.com.

 Good Luck!

 - The Ramp Mobile Team

 */

// = = = = = = = = = = = = = = = = = = = = = = = =

//: [Challenge 1](@previous)
//: #### Challenge 2
//: Get the prompt from Challenge 1 and paste it below.
//: Solve the challenge to get the prompt for Challenge 3.

import Foundation
import PlaygroundSupport

PlaygroundPage.current.needsIndefiniteExecution = true

let prompt = """
Great job!
 
 Next we've hosted a JSON file at at this url: https://api.jsonbin.io/v3/b/646bed328e4aa6225ea22a79. Your job is to write a script to
 download the contents of the URL (hint: The X-ACCESS-KEY is $2b$10$Ke1iwieFO7/7qsSKU.GYU.oYXZMW1EeHrwd4xx9ylboJik5mstZk6)
 sort the data by each elements 'bar' key
 filter out elements where 'baz' is not divisible by 3
 concatenate each elements 'foo' value

 Do each of these steps to reveal the instructions for the final part. Remember to show your work!
"""

// Show your work here! When you are done move on to Challenge 3

/* running curl -H "X-Access-Key: $2b$10$Ke1iwieFO7/7qsSKU.GYU.oYXZMW1EeHrwd4xx9ylboJik5mstZk6" https://api.jsonbin.io/v3/b/646bed328e4aa6225ea22a79*/
/* does not work :( */

import Foundation

let urlLink = "https://api.jsonbin.io/v3/b/646bed328e4aa6225ea22a79"
guard let url = URL(string: urlLink) else {
    print("Invalid URL")
    exit(1)
}

var request = URLRequest(url: url)
request.addValue("$2b$10$Ke1iwieFO7/7qsSKU.GYU.oYXZMW1EeHrwd4xx9ylboJik5mstZk6", forHTTPHeaderField: "X-ACCESS-KEY")

let networkTask = URLSession.shared.dataTask(with: request) { data, response, error in
    DispatchQueue.main.async {
        if let error = error {
            print("Network error: \(error)")
            return
        }

        guard let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200 else {
            print("Bad response")
            return
        }

        guard let data = data else {
            print("No data")
            return
        }

        do {
            if let json = try JSONSerialization.jsonObject(with: data, options: []) as? [String: Any],
               let mainData = json["record"] as? [String: Any],
               let items = mainData["data"] as? [[String: Any]] {

                let result = items
                    .sorted { ($0["bar"] as? Int ?? 0) < ($1["bar"] as? Int ?? 0) }
                    .filter { (($0["baz"] as? Int ?? 0) % 3) == 0 }
                    .compactMap { $0["foo"] as? String }
                    .joined()

                print("Result: \(result)")
            } else {
                print("Wrong format")
            }
        } catch {
            print("JSON error: \(error)")
        }
    }
}

networkTask.resume()
RunLoop.main.run()



//: [Challenge 3](@next)
